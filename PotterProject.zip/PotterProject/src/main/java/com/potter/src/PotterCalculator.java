package com.potter.src;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PotterCalculator {
	
    private List<Set<Integer>> allBooks = null;

    public double totalAmount(Integer[] books) {
    	allBooks = new ArrayList<Set<Integer>>();
    	getSetOfBooks(books);
        return calculateTotalPriceBooks();
    }

    private void getSetOfBooks(Integer[] books) {
        for (int i=0; i < books.length; i++) {
        	Integer book=books[i]; 
        	if (!checkExistingSet(book)) {
        		Set<Integer> s=new HashSet<Integer>();
        		s.add(book);
        		allBooks.add(s);
            }
        	sortSetsForPricing();
        }
        System.out.println(allBooks);
    }


    private double calculateTotalPriceBooks() {
        double totalPrice = 0.0d;
        for (Set<Integer> setOfBooks : allBooks) {
            totalPrice += amountForEachSet(setOfBooks.size());
        }
        return totalPrice;
    }
    
    private void sortSetsForPricing() {
        Collections.sort(allBooks, new Comparator<Set<Integer>>() {
            public int compare(Set<Integer> firstSetOfBooks, Set<Integer> secondSetOfBooks) {
                if (firstSetOfBooks.size() == 3)
                		return -1;
                if (secondSetOfBooks.size() == 3) 
                		return 1;
                return ((Integer) secondSetOfBooks.size()).compareTo(firstSetOfBooks.size());
            }
        });
    }

   private boolean checkExistingSet(Integer book) {
        for (Set<Integer> aSetOfBooks : allBooks) {
            if (!aSetOfBooks.contains(book)) {
                aSetOfBooks.add(book);
                return true;
            }
        }
        return false;
   }

  private double amountForEachSet(int bookCount) {
        double discount = 0.05d * bookCount;
        double priceBeforeDiscount = bookCount * 8.0d;
        return priceBeforeDiscount - (priceBeforeDiscount * discount);
  }
    
  public static void main(String args[]){
	  PotterCalculator calculator= new PotterCalculator();
	  System.out.println(calculator.totalAmount(new Integer[]{1,1,2,2,3,3,4,5}));
  }  
}